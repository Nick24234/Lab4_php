module PostsHelper
end

