module ApplicationHelper
end

